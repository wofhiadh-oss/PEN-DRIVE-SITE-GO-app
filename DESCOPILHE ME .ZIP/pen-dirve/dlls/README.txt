Esta pasta é para arquivos DLL que seu site possa precisar.

Coloque aqui quaisquer bibliotecas .dll necessárias para o funcionamento do seu site.
